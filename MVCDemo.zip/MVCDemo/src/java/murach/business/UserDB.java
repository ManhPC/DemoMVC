/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package murach.business;

import java.io.*;
public class UserDB implements Serializable{

    private User user;

    public UserDB(User user) {
        this.user = user;
    }
    
    public void insert(String url) throws FileNotFoundException, IOException{
        //DataOutputStream out=new DataOutputStream(new FileOutputStream(url));
        FileWriter out=new FileWriter(new File(url), true);
        out.write(user.toString());
        out.close();
    }
}
