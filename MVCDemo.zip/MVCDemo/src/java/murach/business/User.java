package murach.business;

import java.io.Serializable;

public class User implements Serializable {
    private String firstName;
    private String lastName;
    private String email;
    String gender;
    private String[] music;
    public User() {
        firstName = "";
        lastName = "";
        email = "";
        gender = "";
        music = new String[4];
    }
    public User(String firstName, String lastName, String email,String gender,String[] music) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.gender = gender;
        this.music = music;
        
    }


    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String[] getMusic() {
        return music;
    }

    public void setMusic(String[] music) {
        this.music = music;
    }
    
    @Override
    public String toString() {
        String ans = email + "\\" + firstName + "\\" + lastName+"\\";
        for (int i = 0; i < music.length; i++) {
            ans += music[i]+", ";
        }
        ans=ans.substring(0, ans.length()-2);
        ans+="\n";
        return ans;
    }
}