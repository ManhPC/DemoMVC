package murach.email;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.jws.soap.InitParam;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import murach.business.User;
import murach.data.UserDB;
//import murach.data.UserDB;

public class EmailListServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = "/index.jsp";
        // get current action 
        String action = request.getParameter("action");
        if (action == null) {
            action = "join"; // default action 
        }
// perform action and set URL to appropriate page  
        if (action.equals("join")) {
            url = "/index.jsp"; // the "join" page  
        } else if (action.equals("add")) {
            // get parameters from the request 
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            String gender = request.getParameter("gender");
            String edu = request.getParameter("education");
            String []lmusic=request.getParameterValues("lmusic");
            List <String> list=new ArrayList<>();
            if(lmusic!=null){
                list=Arrays.asList(lmusic);
            }
            else{
                list.add("");
            }
         
            
            // store data in User object and save User object in db 
            boolean ok=true;
            String message1="",message2="", message3="";
            //email
//            ArrayList music=new ArrayList();
//            music.add(rock);
            if(email.isEmpty()){
                ok=false;
                message1="Hay nhap email!";
            }
            //firstname
            if(firstName.isEmpty()){
                ok=false;
                message2="Hay nhap Ten";
            }
            //lastname
            if(lastName.isEmpty()){
                ok=false;
                message3="Hay nhap Ho";
            }
            User user = new User(firstName, lastName, email, gender, edu,list);
            ServletContext context = this.getServletContext();
            String path = context.getRealPath("/WEB-INF/EmailList.txt");
            if(!UserDB.emailExist(email, path)){
                message1="email da ton tai!";
                ok=false;
            }
            if(ok){
                // store data in User object and save User object in db
                
                UserDB.insert(user, path); 
                
                //UserDB.insert(user);
                // set User object in request object and set URL
                request.setAttribute("user", user);
                url = "/thanks.jsp";   // the "thanks" page
            }
            else{
                request.setAttribute("message1", message1);
                request.setAttribute("message2", message2);
                request.setAttribute("message3", message3);
                request.setAttribute("firstname", firstName);
                request.setAttribute("email", email);
                request.setAttribute("lastname", lastName);
                url="/index.jsp";
            }
            
        }

        // forward request and response objects to specified URL  
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
