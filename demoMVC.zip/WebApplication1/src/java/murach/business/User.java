package murach.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable {

    private String firstName, lastName, email, gender, edu;
    private List<String> lmusic;
    public User() {
        firstName = "";
        lastName = "";
        email = "";
        gender = "";
        edu = "";
        lmusic=new ArrayList<String>();
    }

    public User(String firstName, String lastName, String email, String gender, String edu, List<String> lmusic) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.gender = gender;
        this.edu = edu;
        this.lmusic = lmusic;
    }

    

    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }

    public void setEdu(String edu) {
        this.edu = edu;
    }

    public String getEdu() {
        return edu;
    }

    public String getLmusic() {
        String music = "";
        if (lmusic.size() == 1 && lmusic.get(0).equals(""))
            return "Khong co";
        else {
            for (String x : lmusic) {
                music += x + " | ";
            }
            return music;
        }
            
    }

    public void setLmusic(List<String> lmusic) {
        this.lmusic = lmusic;
    }
    
}
