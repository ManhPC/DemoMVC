package murach.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import murach.business.User;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
public class UserDB {
    private User user;

    public UserDB(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    public static void insert(User user, String path) throws IOException {
        File file = new File(path);
        if(!file.exists()){
            file.createNewFile();
        }
        FileWriter fw = new FileWriter(path, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String s = user.getEmail()+ "|" + user.getFirstName()+ "|" + user.getLastName()+ "|" + user.getLmusic();
        bw.write(s);
        bw.close();
    }
     public static boolean emailExist(String email, String path) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(path));
        List<String> listEmail = new ArrayList<>();
        while (sc.hasNextLine()) {
            String[] in4 = sc.nextLine().split("\\|");
            listEmail.add(in4[0]);
        }
        for (String x : listEmail) {
            if (x.equals(email)) {
                return false;
            }
        }
        return true;
    }
}
